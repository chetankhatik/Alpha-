function  changeimg0(){
    document.getElementById("chetan").src="./Images/super-meteor-650.avif";
}
function  changeimg1(){
    document.getElementById("chetan").src="./Images/hunter2avif.avif";
}
function  changeimg2(){
    document.getElementById("chetan").src="./Images/hunter3.avif";
}
function  changeimg3(){
    document.getElementById("chetan").src="./Images/hunter5.avif";
}
function  changeimg4(){
    document.getElementById("chetan").src="./Images/hunter6.avif";
}
function  changeimg5(){
    document.getElementById("chetan").src="./Images/hunter8.avif";
}
function  changeimg6(){
    document.getElementById("chetan").src="./Images/hunter10.avif";
}

function  changeimg7(){
    document.getElementById("chetan").src="./Images/hunter11.avif";
}
function  changeimg8(){
    document.getElementById("chetan").src="./Images/hunter3.avif";
}

function navimage1()
{
    document.getElementById("ckk").src="./Images/royal-enfield-trail-school.avif";

}
function navimage2()
{
    document.getElementById("ckk").src="./Images/NI1.avif";

}
function navimage3()
{
    document.getElementById("ckk").src="./Images/NI2.avif";

}

function Anavimage1()
{
    document.getElementById("ckk2").src="./Images/3NI1.jpg";

}
function Anavimage2()
{
    document.getElementById("ckk2").src="./Images/3NI2.avif";

}
function Anavimage3()
{
    document.getElementById("ckk2").src="./Images/3NI3.avif";
   
}
function Anavimage4()
{
    document.getElementById("ckk2").src="./Images/3NI4.avif";

}
function Anavimage5()
{
    document.getElementById("ckk2").src="./Images/3NI5.avif";

}
function Anavimage6()
{
    document.getElementById("ckk2").src="./Images/3NI6.avif";

}
function Anavimage7()
{
    document.getElementById("ckk2").src="./Images/3NI7.avif";

}
function Bnavimage1()
{
    document.getElementById("ckk3").src="./Images/4NI2.avif";

}
function Bnavimage2()
{
    document.getElementById("ckk3").src="./Images/4NI1.avif";

}

function Cnavimage1()
{
    document.getElementById("ckk4").src="./Images/5NI1.avif";

}
function Cnavimage2()
{
    document.getElementById("ckk4").src="./Images/5NI2.avif";

}
function Cnavimage3()
{
    
    document.getElementById("ckk4").src="./Images/5NI3.avif";

}


